```python
# Standard Libraries
import math
import random
import sys
from datetime import date, time, datetime
import datetime as dt
import warnings
import locale

# Data Manipulation and Analysis
import pandas as pd
import numpy as np
import re, unicodedata
import calendar as cal
import string
import statistics as st
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.cluster import KMeans
import statsmodels.api as sm 
from scipy import stats

# Data Visualization
from matplotlib import pyplot as plt
import seaborn as sns
from pylab import *
from tqdm import tqdm

# Excel Export
import xlsxwriter

# Configuracion Tabla Visualization
pd.set_option('display.max_columns',2000)
```


```python
# Ajuste y cambio de nombres a las columnas
def clean_text(text):
    '''
    le pasas una frase y te hace la sustición de toda la simbologia
    
    '''
    res = unicodedata.normalize('NFD', text).encode('ascii', 'ignore')
    res = re.sub("[^a-zA-Z0-9 ]"," ", res.decode("utf-8"), flags=re.UNICODE)
    res = u' '.join(res.upper().split())
    return res

def rename_col(df, col, prefijo):
    new_col = [prefijo+'_' +
               '_'.join(x.strip().upper().split(' ')) for x in col]
    new_col = [unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode(
        "ascii").replace('\n', '').replace('.', '') for s in new_col]
    df.rename(columns=dict(zip(col, new_col)), inplace=True)

# Creacion de completitud tabla
def completitud(df, solo_nulos=True):
    aux = df.isnull().sum().reset_index().rename(
        columns={'index': 'columna', 0: 'absoluto'})
    aux['%'] = aux['absoluto']/df.shape[0]
    if solo_nulos:
        return aux[aux['absoluto'] > 0]
    else:
        return aux

# Descripcion de tabla
def desc_table(df):
    n = 50
    simbolo = '*'
    k = 2  # saltos de linea

    print(' DIMENSIONES DE LA TABLA'.center(n, *), end='\n'*k)
    display(df.shape)
    print(' MUESTRA DE TABLAS'.center(n, simbolo), end='\n'*k)
    display(df.head())
    print(' INFORMACION DE COLUMNAS'.center(n, *), end='\n'*k)
    display(df.info())
    print(' TABLA DE COMPLETITUD'.center(n, *), end='\n'*k)
    display(completitud(df))
    print(' DUPLICADOS'.center(n, *), end='\n'*k)
    display(df.duplicated().sum())

```


```python
link_info = r'C:\Users\1294082\OneDrive - Autos Pullman, S.A. de C.V\Escritorio'
```


```python
activity_data = pd.read_csv(link_info + '\\' + 'activity.csv', encoding='latin1')

```


```python
# Show information
activity_data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>steps</th>
      <th>date</th>
      <th>interval</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>10</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>15</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>20</td>
    </tr>
  </tbody>
</table>
</div>




```python
activity_data.columns
```




    Index(['steps', 'date', 'interval'], dtype='object')



# Exploration 


```python
desc_table(activity_data)
```

    ************* DIMENSIONES DE LA TABLA*************
    
    


    (17568, 3)


    **************** MUESTRA DE TABLAS****************
    
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>steps</th>
      <th>date</th>
      <th>interval</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>10</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>15</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>20</td>
    </tr>
  </tbody>
</table>
</div>


    ************* INFORMACION DE COLUMNAS*************
    
    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 17568 entries, 0 to 17567
    Data columns (total 3 columns):
     #   Column    Non-Null Count  Dtype  
    ---  ------    --------------  -----  
     0   steps     15264 non-null  float64
     1   date      17568 non-null  object 
     2   interval  17568 non-null  int64  
    dtypes: float64(1), int64(1), object(1)
    memory usage: 411.9+ KB
    


    None


    ************** TABLA DE COMPLETITUD***************
    
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>columna</th>
      <th>absoluto</th>
      <th>%</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>steps</td>
      <td>2304</td>
      <td>0.131148</td>
    </tr>
  </tbody>
</table>
</div>


    ******************* DUPLICADOS********************
    
    


    0



```python
#Ajuste a mayusculas de las columnas del dataframe
activity_data.columns      =  [clean_text(i).replace(' ','_').upper()  for i in activity_data.columns.tolist() ]
```


```python
activity_data.head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>STEPS</th>
      <th>DATE</th>
      <th>INTERVAL</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>5</td>
    </tr>
    <tr>
      <th>2</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>10</td>
    </tr>
    <tr>
      <th>3</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>15</td>
    </tr>
    <tr>
      <th>4</th>
      <td>NaN</td>
      <td>2012-10-01</td>
      <td>20</td>
    </tr>
  </tbody>
</table>
</div>



# Cleaning Data


```python
activity_data['DATE'] = pd.to_datetime(activity_data['DATE'],yearfirst=True)
```


```python
activity_data['YEAR'] = activity_data['DATE'].dt.year
```


```python
activity_data['MOUNT'] = activity_data['DATE'].dt.month
```


```python
activity_data['WEEKDAY'] = activity_data['DATE'].dt.dayofweek
```


```python
# Define a dictionary to map weekday numbers to their names
weekday_mapping = {
    0: 'Monday',
    1: 'Tuesday',
    2: 'Wednesday',
    3: 'Thursday',
    4: 'Friday',
    5: 'Saturday',
    6: 'Sunday'
}

# Use the map function to replace values in the 'WEEKDAY' column
activity_data['WEEKDAY'] = activity_data['WEEKDAY'].map(weekday_mapping).fillna('Error')
```


```python
# Assuming activity_data is your DataFrame
activity_data['STEPS'].replace('NA', np.nan, inplace=True)
```


```python
activity_data['STEPS'].dtype
```




    dtype('float64')



# Creating AUX TABLES to view analisis


```python
df_order = activity_data[['YEAR','MOUNT','DATE','WEEKDAY','INTERVAL','STEPS']].reset_index(drop=True)
```


```python
df_order.sort_values(by = 'DATE',inplace = True)
```

# Plot


```python
# Adjust the figure size as needed
plt.figure(figsize=(10, 6))  

# Create the scatterplot with hue for coloring by 'INTERVAL'
sns.scatterplot(data=df_order, x='DATE', y='STEPS', hue='INTERVAL')

# Rotate the x-axis labels by 45 degrees
plt.xticks(rotation=45)

plt.show()
```


    
![png](output_22_0.png)
    



```python
# Adjust the figure size as needed
plt.figure(figsize=(10, 6))  

# Create the scatterplot with hue for coloring by 'INTERVAL'
sns.scatterplot(data=df_order, x='INTERVAL', y='STEPS', hue = 'WEEKDAY' ,size='WEEKDAY')
sns.set_palette("pastel")
# Rotate the x-axis labels by 45 degrees
plt.xticks(rotation=45)

plt.show()
```


    
![png](output_23_0.png)
    



```python
# Adjust the figure size as needed
plt.figure(figsize=(10, 6))  

# Create the scatterplot with hue for coloring by 'INTERVAL'
sns.scatterplot(data=df_order, x='WEEKDAY', y='STEPS', hue='INTERVAL')

# Rotate the x-axis labels by 45 degrees
plt.xticks(rotation=45)

plt.show()
```


    
![png](output_24_0.png)
    



```python
# Adjust the figure size as needed
plt.figure(figsize=(10, 6))  

# Create the scatterplot with hue for coloring by 'INTERVAL'
sns.scatterplot(data=df_order[df_order['WEEKDAY']=='Monday'], x='DATE', y='STEPS', hue='INTERVAL')

# Rotate the x-axis labels by 45 degrees
plt.xticks(rotation=45)

plt.show()
```


    
![png](output_25_0.png)
    



```python
plt.figure(figsize=(16, 8))  # Adjust the figure size as needed

# Create the histogram with hue for coloring by 'INTERVAL'
sns.histplot(data=df_order,x = 'STEPS', y = 'INTERVAL')

# Rotate the x-axis labels by 45 degrees
plt.xticks(rotation=45)
plt.xlabel('WEEKDAY')
plt.ylabel('Count')
plt.title('Histogram of Steps per Day by Weekday and Interval')
plt.show()
```


    
![png](output_26_0.png)
    



```python
# Get unique weekdays
unique_weekdays = df_order['WEEKDAY'].unique()

# Loop through unique weekdays and create scatterplots
for weekday in unique_weekdays:
    # Adjust the figure size as needed
    plt.figure(figsize=(10, 6))  
    
    # Filter the DataFrame for the current weekday
    data_for_weekday = df_order[df_order['WEEKDAY'] == weekday]
    
    # Create the scatterplot with hue for coloring by 'INTERVAL'
    ax = sns.scatterplot(data=data_for_weekday, x='INTERVAL', y='STEPS', hue='INTERVAL')
    
    # Rotate the x-axis labels by 45 degrees
    ax.set_title(weekday)  # Set the title for the current plot
    plt.xticks(rotation=45)
    
    # Show the plot for the current weekday
    plt.show()
```


    
![png](output_27_0.png)
    



    
![png](output_27_1.png)
    



    
![png](output_27_2.png)
    



    
![png](output_27_3.png)
    



    
![png](output_27_4.png)
    



    
![png](output_27_5.png)
    



    
![png](output_27_6.png)
    



```python
# Adjust the figure size as needed
plt.figure(figsize=(10, 6))  

# Create the scatterplot with hue for coloring by 'INTERVAL'
sns.boxplot(data = df_order, x='WEEKDAY', y='STEPS'#,hue = 'INTERVAL'
           )

# Rotate the x-axis labels by 45 degrees
plt.xticks(rotation=90)

plt.show()
```


    
![png](output_28_0.png)
    

